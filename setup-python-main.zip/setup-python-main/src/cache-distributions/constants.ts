export const CACHE_DEPENDENCY_BACKUP_PATH = '**/pyproject.toml';
