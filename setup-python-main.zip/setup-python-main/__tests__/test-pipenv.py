import numpy as np

a = np.array([2, 3, 4])
print(type(a))

b = np.array([1.2, 3.5, 5.1])
print(type(b))